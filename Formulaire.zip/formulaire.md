# Formulaire:

1) En tenant compte du travail effectué, quels sont les prérequis nécessaires pour utiliser un réseau de neurones ?

```
```

2) A quoi correspond le paramètre `epochs` utilisé dans l'entraînement du modèle ?

```
```

3) Que faudrait-il faire pour que le modèle soit plus précis ?

- [ ] Augmenter le nombre d'epoch 
- [ ] Diminuer le nombre d'epoch
- [ ] Augmenter le batch size
- [ ] Diminuer le batch size
- [ ] Augmenter le dataset
- [ ] Diminuer le dataset
- [ ] Avoir de meilleur composant
- [ ] Augmenter le nombre de couche dans le model 
- [ ] Diminuer le nombre de couche dans le model 
- [ ] Mon modèle & préparation des données sont parfaits

4) L'apprentissage du modèle s'est-il fait de manière supervisée ou non supervisée ? Pourquoi ?

```
```

5) Quel sont les meilleurs pourcentages de découpage du dataset ? (entrainement, test)

```
```

6) Pouvez-vous citer les 3 groupes (layer, output, input) qui caractérisent un réseau neuronal  (image ci-dessous) ?
![](https://imgur.com/Y30MDF0.jpg)


Détailler brièvement le rôle de chaque groupe.

```
```